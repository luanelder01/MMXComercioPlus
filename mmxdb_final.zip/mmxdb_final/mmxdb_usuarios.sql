-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: mmxdb
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) NOT NULL,
  `cpf` varchar(14) NOT NULL,
  `endereco` varchar(255) NOT NULL,
  `data_nascimento` date NOT NULL,
  `profissao` varchar(50) NOT NULL,
  `salario` decimal(10,2) NOT NULL,
  `telefone` varchar(15) NOT NULL,
  `senha` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cpf` (`cpf`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (1,'Gustavo','123.456.789-09','Rua Exemplo, 123','1990-05-15','Administrador',5000.00,'31 9999-9999','123'),(2,'Ana Silva','987.654.321-01','Avenida Principal, 456','1985-12-22','Analista de Marketing',4000.00,'31 8888-8888','senha123'),(3,'Carlos Santos','456.789.012-34','Travessa do Centro, 789','1988-08-10','Engenheiro Civil',6000.00,'31 7777-7777','senha456'),(4,'Juliana Oliveira','234.567.890-45','Praça da Liberdade, 112','1995-03-28','Contadora',5500.00,'31 6666-6666','senha789'),(5,'Ricardo Pereira','789.012.345-67','Alameda dos Sonhos, 876','1980-11-05','Advogado',7000.00,'31 5555-5555','senhaABC'),(6,'Fernanda Lima','345.678.901-23','Avenida dos Artistas, 321','1992-09-18','Arquiteta',6500.00,'31 4444-4444','senhaDEF'),(7,'Pedro Souza','012.345.678-90','Rua da Esquina, 543','1983-07-14','Programador',5500.00,'31 3333-3333','senhaGHI'),(8,'Camila Santos','901.234.567-89','Rua das Flores, 876','1998-01-30','Estudante',0.00,'31 2222-2222','senhaJKL'),(9,'Lucas Oliveira','567.890.123-45','Avenida dos Esportes, 987','1987-06-25','Professor',4500.00,'31 1111-1111','senhaMNO'),(10,'Mariana Costa','210.987.654-32','Praia da Felicidade, 654','1993-04-12','Médica',8000.00,'31 0000-0000','senhaPQR'),(11,'Deiverson','111.111.111-99','Rua das ostras','1999-02-20','Administrador',1000.00,'3199999999','123');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-07 20:32:26
